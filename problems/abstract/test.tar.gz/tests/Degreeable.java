public interface Degreeable {
    public void awardDegree();
}