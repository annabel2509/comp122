public interface Emailable {
    public void sendEmail();
}