public interface Billable {
    public void payBill(int amount);
}