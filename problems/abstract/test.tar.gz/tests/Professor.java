public class Professor extends Lecturer {
    private int budget;
    
    public void setBudget(int new_budget) {
      budget = new_budget;
    }
    
    public int getBudget() {
      return budget;
    }
}
