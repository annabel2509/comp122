public interface Payable {
    public void payAmount(int amount);
}