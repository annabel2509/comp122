public class Dog implements Degreeable {
    boolean goodGirl = true;

    public void awardDegree() {
        if (goodGirl) {
            System.out.println("Arruff woof woof. WOOF!");
        }
    }
}